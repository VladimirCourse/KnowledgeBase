package exceptions;

/**
 * Created by vova on 13.08.16.
 */
public class CustomException extends Exception {

    public CustomException() {

    }

    public CustomException(String message) {
        super(message);
    }
}
